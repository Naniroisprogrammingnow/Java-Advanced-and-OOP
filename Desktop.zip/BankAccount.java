public class BankAccount {

    private static final double RATE_DEFAILT_VALUE = 0.02;
    public static int idCounter = 1;
    private int id;
    private double balance;
    private static double interrestRate=RATE_DEFAILT_VALUE;

    public BankAccount(){
        this.id = idCounter++;
        this.balance = 0;
    }

    public int getId() {
        return id;
    }

    public static void setInterrestRate(double inerest){
         interrestRate = inerest;
    }
    public double getInterest(int years){
        return years*interrestRate*this.balance;
    }
    public void deposit (double amount){
        this.balance+=amount;
    }

}
