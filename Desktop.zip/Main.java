import java.text.DecimalFormat;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String line;
        Map<Integer, BankAccount> accounts = new LinkedHashMap<>();
        while (!"End".equals(line = scanner.nextLine())){
            String[] tokens = line.split("\\s+");
            switch (tokens.length){
                case 1:
                    BankAccount newAccount = new BankAccount();
                    accounts.put(newAccount.getId(), newAccount);
                    System.out.printf("Account ID%d created%n", newAccount.getId());
                    break;
                case 2:
                    BankAccount.setInterrestRate(Double.parseDouble(tokens[1]));
                    break;
                case 3:
                    int id = Integer.parseInt(tokens[1]);
                    if(!accounts.containsKey(id)){
                        System.out.println("Account does not exist");
                    }else{
                        BankAccount ba = accounts.get(id);
                        if (tokens[0].equals("Deposit")){
                            double sum = Double.parseDouble(tokens[2]);
                            ba.deposit(sum);
                            DecimalFormat format = new DecimalFormat("#####.####");
                            System.out.printf("Deposited %s to ID%d%n", format.format(sum),id);
                        }else {
                            int years = Integer.parseInt(tokens[2]);
                            System.out.printf("%.2f%n", ba.getInterest(years));
                        }
                    }

                    break;
            }
        }
    }
}
